import 'package:flutter/material.dart';
import 'package:graduation/presentation/screens/on_bording2.dart';

class ONBORDING1 extends StatelessWidget {
  const ONBORDING1({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        actions: [
          InkWell(onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (builder)=>ONBORDING2()));
          },
              child:
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: Text("Skip",style: TextStyle(fontSize: 19,fontWeight: FontWeight.bold),),
              ))
        ],
        backgroundColor: Color(0xff9D659B),
        iconTheme: IconThemeData(color: Colors.white),),
      body: SingleChildScrollView(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  new Container(
                    height: 400.0,
                    decoration: new BoxDecoration(
                      color: Color(0xff9D659B),
                      boxShadow: [
                        new BoxShadow(blurRadius: 40.0)
                      ],
                      borderRadius: new BorderRadius.vertical(
                          bottom: new Radius.elliptical(
                              MediaQuery.of(context).size.width, 100.0)),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 40.0),
                    child: Center(
                      child: Column(
                          children: [
                            Image.asset(
                              'assets/images/Group 41.png',
                              width: 306.59,
                              height: 340.0,
                            ) ] ),
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: [
                    Text(
                      "Chatbot",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Column(
                children: [
                  Text("computer program or AI system that assists",style: TextStyle(fontSize: 15),),
                  Text("individuals with ADHD by providing support",style: TextStyle(fontSize: 15),),
                  Text("reminders, and information through text-based or",style: TextStyle(fontSize: 15),),
                  Text("spoken conversations, helping them manage their",style: TextStyle(fontSize: 15),), Text("daily tasks and challenges related to the condition",style: TextStyle(fontSize: 15),),
                  // Text(
                  //   "computer program or AI system that assists \nindividuals with ADHD by providing support,\nreminders, and information through text-based or\n spoken conversations, helping them manage their\n daily tasks and challenges related to the condition",
                  // style: TextStyle(fontSize: 15),),
                  SizedBox(
                    height: 25,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color:  Color(0xff15596F),
                        borderRadius: BorderRadius.circular(16)),
                    width: 250,
                    height: 41,
                    alignment: Alignment.center,
                    child: Center(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Next",style: TextStyle(color: Colors.white,fontSize: 16)),
                          Icon(Icons.keyboard_double_arrow_right_outlined,color: Colors.white,)
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}