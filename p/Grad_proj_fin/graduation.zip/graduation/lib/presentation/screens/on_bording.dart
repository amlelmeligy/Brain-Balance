//}Image.asset("assets/images/Group 51.png")
// import 'package:flutter/material.dart';
//
// class ThemeProvider with ChangeNotifier {
//   bool _isDarkMode = false;
//
//   ThemeData get themeData => _isDarkMode ? _darkTheme : _lightTheme;
//
//   bool get isDarkMode => _isDarkMode;
//
//   void toggleTheme() {
//     _isDarkMode = !_isDarkMode;
//     notifyListeners();
//   }
//
//   static ThemeData _lightTheme = ThemeData(
//     // Define your light theme here
//     brightness: Brightness.light,
//     // Other theme properties...
//   );
//
//   static ThemeData _darkTheme = ThemeData(
//     // Define your dark theme here
//     brightness: Brightness.dark,
//     // Other theme properties...
//   );
// }

