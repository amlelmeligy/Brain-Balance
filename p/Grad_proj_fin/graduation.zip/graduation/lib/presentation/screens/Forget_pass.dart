import 'package:flutter/material.dart';
import 'package:graduation/presentation/screens/log_in.dart';
import 'package:graduation/presentation/screens/on_boding3.dart';
import 'package:graduation/presentation/screens/on_bording2.dart';

class FORGET extends StatelessWidget {
  const FORGET({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(scrollDirection: Axis.vertical,
      child: Scaffold(
        appBar: AppBar(leading: InkWell(onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (builder)=>ONBORDING3()));},
            child: Icon(Icons.arrow_back_ios_new_sharp,color: Colors.black,)),
          backgroundColor: Color(0xffBE88BC),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  new Container(
                    height: 350.0,
                    decoration: new BoxDecoration(
                      color: Color(0xffBE88BC),
                      boxShadow: [new BoxShadow(blurRadius: 40.0)],
                      borderRadius: new BorderRadius.vertical(
                          bottom: new Radius.elliptical(
                              MediaQuery.of(context).size.width, 300.0)),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 40.0),
                    child: Center(
                      child: Column(children: [
                        Image.asset(
                          'assets/images/Forgetpass.png',
                          width: 306.59,
                          height: 340.0,
                        )
                      ]),
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: [
                    Text(
                      "Forget password??",
                      style: TextStyle(fontFamily: 'Outfit',fontWeight: FontWeight.bold, fontSize: 20),
                    )
                  ],
                ),
              ),
              Column(
                children: [
                  Text(
                    "Don’t worry ! it happens . please enter email address",
                    style: TextStyle(fontSize: 14,fontFamily: 'Outfit'),
                  ),
                  Text(
                    " associated with your account ... ",
                    style: TextStyle(fontSize: 14,fontFamily: 'Outfit'),
                  ),

                  SizedBox(
                    height: 40,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 15),
                    child: TextFormField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25)),
                     //     labelText: 'Email',
                          hintText: '@user@gmail.com'),
                    ),
                  ),SizedBox(height: 60,),
                  Container(
                    decoration: BoxDecoration(
                        color: Color(0xff15596F),
                        borderRadius: BorderRadius.circular(16)),
                    width: 336,
                    height: 46,
                    alignment: Alignment.center,
                    child: Center(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Submit",
                              style: TextStyle(color: Colors.white, fontSize: 16)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
