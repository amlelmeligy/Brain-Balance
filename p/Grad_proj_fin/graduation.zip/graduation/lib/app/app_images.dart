import 'dart:core';

class AppImages{
  static const String imagepath="assets/images/";
  static const String pic="assets/images/onbording4.png";
  static const String pic1="${imagepath}";
  static const String pic2="";
}