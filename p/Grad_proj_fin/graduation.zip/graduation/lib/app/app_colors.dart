import 'dart:ui';

class AppColors{
  static const buttonColor=Color(0xff606FF2);
  static const fontColor=Color(0xFF000000);
  static const circleColor=Color(0xFF707070);

}