package com.example.graduation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
